import numpy as np
import scipy.sparse as sp

def load_cora():
    print('Loading Cora dataset...')
    idx_features_labels = np.genfromtxt("cora.content", dtype=np.dtype(str))
    features = sp.csr_matrix(idx_features_labels[:, 1:-1], dtype=np.float32).toarray()
    labels = encode_labels(idx_features_labels[:, -1])
    return features, labels

def encode_labels(labels):
    classes = set(labels)
    classes_dict = {c: np.identity(len(classes))[i, :] for i, c in enumerate(classes)}
    labels_onehot = np.array(list(map(classes_dict.get, labels)), dtype=np.int32)
    return np.argmax(labels_onehot, axis=1)

if __name__ == "__main__":
    features, labels = load_cora()
    np.save('features.npy', features)
    np.save('labels.npy', labels)
    print("Features and labels saved to 'features.npy' and 'labels.npy'")
