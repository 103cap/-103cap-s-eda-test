import torch
import torch.nn as nn

class GraphCNN(nn.Module):
    """图卷积神经网络模型，用于对数据进行卷积提取特征并分类。

    Attributes:
        features (nn.Sequential): 卷积层序列，用于提取特征。
        classifier (nn.Sequential): 全连接分类器，用于最终分类。
        _to_linear (int): 卷积层输出展平后的特征数。
    """
    
    def __init__(self, num_features, num_class):
        """初始化 GraphCNN 模型。

        Args:
            num_features (int): 输入数据的特征数量（序列长度）。
            num_class (int): 输出类别数。
        """
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv1d(1, 8, kernel_size=3, padding=1),  # 通道从 16→8（防止过拟合）
            nn.ReLU(),
            nn.MaxPool1d(2),
    
            nn.Conv1d(8, 16, kernel_size=3, padding=1),  # 通道从 32→16（防止过拟合）
            nn.ReLU(),
            nn.MaxPool1d(2)
        )
        
        self._to_linear = None
        self._get_conv_output(num_features)  # 调用前必须确保已导入torch
        
        self.classifier = nn.Sequential(
            nn.Linear(self._to_linear, 64),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(64, num_class)
        )

    def _get_conv_output(self, shape):
        """计算卷积层输出的展平维度，用于初始化全连接层。

        Args:
            shape (int): 输入数据的特征维度长度。
        """
        with torch.no_grad():
            dummy = torch.zeros(1, 1, shape)
            dummy = self.features(dummy)
            self._to_linear = dummy.view(1, -1).size(1)

    def forward(self, x):
        """前向传播方法。

        Args:
            x (torch.Tensor): 输入张量，其形状应满足卷积层要求。

        Returns:
            torch.Tensor: 模型输出张量，包含预测的类别分数。
        """
        x = self.features(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x