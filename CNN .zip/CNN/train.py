import torch  # 导入 PyTorch 库，用于深度学习框架
import torch.nn as nn  # 导入神经网络模块，包含常用的层和激活函数
import torch.optim as optim  # 导入优化器模块，提供优化算法（例如Adam）
from torch.utils.data import DataLoader, TensorDataset  # 导入数据加载器和数据集类，可帮助批量加载数据
from tqdm import tqdm  # 导入tqdm，训练进度可视化（在对大型数据库如COVID_19数据库分析时效果较好）
import numpy as np  # 导入NumPy库，用于数值计算和数组处理
import time  # 导入时间模块，用于计算训练时间
import psutil  # 导入psutil库，用于监控内存使用情况
from model.cnn import GraphCNN  # 导入自定义模型GraphCNN

# 根据当前设备是否支持CUDA（GPU）设置使用的运算设备
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 定义数据预处理函数，将所有数据划分为训练，验证和测试集
def preprocess_data(features, labels, test_size=0.1, val_size=0.112):
    num_samples = features.shape[0]  # 获取样本总数
    indices = np.arange(num_samples)  # 生成样本索引数组
    np.random.shuffle(indices)  # 随机打乱索引，保证数据划分的随机性
    
    test_split = int(test_size * num_samples)  # 计算测试集大小，取总样本数的10%
    val_split = int(val_size * (num_samples - test_split))  # 计算验证集大小，从剩余样本中取1/9(8:1:1不重复取)
    
    test_indices = indices[:test_split]  # 前test_split个索引用于测试集
    val_indices = indices[test_split:test_split + val_split]  # 后续的val_split个索引用于验证集
    train_indices = indices[test_split + val_split:]  # 剩余的索引用于训练集
    
    # 根据索引从特征数组中提取对应的样本
    train_features = features[train_indices]
    val_features = features[val_indices]
    test_features = features[test_indices]
    
    # 同样地，从标签数组中提取对应的标签
    train_labels = labels[train_indices]
    val_labels = labels[val_indices]
    test_labels = labels[test_indices]
    
    # 返回划分好的训练、验证和测试集
    return (train_features, train_labels), (val_features, val_labels), (test_features, test_labels)

# 从存储的文件中加载特征和标签数据
features = np.load('features.npy')  # 加载特征数据，假定尺寸为 (样本数, 特征数)
labels = np.load('labels.npy')  # 加载标签数据

# 使用preprocess_data函数划分数据集（8:1:1划分比例对应此处测试和验证均为10%）
(train_features, train_labels), (val_features, val_labels), (test_features, test_labels) = preprocess_data(features, labels)

# 构造训练集TensorDataset
# unsqueeze(1)用于增加一个通道维度，使得每个样本的形状从 (num_features) 变为 (1, num_features)
train_dataset = TensorDataset(
    torch.tensor(train_features, dtype=torch.float32).unsqueeze(1),  # 将训练特征转换为Tensor并添加通道维度
    torch.tensor(train_labels, dtype=torch.long)  # 将训练标签转换为LongTensor
)

# 构造验证集TensorDataset，逻辑同上
val_dataset = TensorDataset(
    torch.tensor(val_features, dtype=torch.float32).unsqueeze(1),
    torch.tensor(val_labels, dtype=torch.long)
)

# 构造测试集TensorDataset
test_dataset = TensorDataset(
    torch.tensor(test_features, dtype=torch.float32).unsqueeze(1),
    torch.tensor(test_labels, dtype=torch.long)
)

# 用DataLoader封装每个数据集，设置批量大小（batch_size=32）
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)  # 训练集需要打乱顺序
val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False)  # 验证集无需打乱
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)  # 测试集无需打乱

# 定义训练函数，包含训练循环和验证
def train(model, train_loader, val_loader, criterion, optimizer, num_epochs):
    best_acc = 0.0
    for epoch in range(num_epochs):
        epoch_start = time.time()
        model.train()
        running_loss = 0.0
        for inputs, labels in tqdm(train_loader, desc=f"epoch:{epoch+1}/{num_epochs}", unit="batch"):
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * inputs.size(0)
        epoch_loss = running_loss / len(train_loader.dataset)
        epoch_time = time.time() - epoch_start
        process = psutil.Process()
        memory_usage = process.memory_info().rss / (1024 * 1024)
        print(f"epoch[{epoch+1}/{num_epochs}], Train_loss: {epoch_loss:.4f}, Time: {epoch_time:.2f}s, Memory usage: {memory_usage:.2f}MB")
        
        accuracy = evaluate(model, val_loader, criterion)
        if accuracy > best_acc:
            best_acc = accuracy
            save_model(model, save_path)
            print("model saved with best acc", best_acc)

# 定义评估函数，用于在验证或测试集上进行模型测试
def evaluate(model, data_loader, criterion):
    model.eval()  # 设置模型为评估模式（关闭Dropout等）
    test_loss = 0.0  # 初始化累计损失
    correct = 0  # 初始化正确预测的样本数
    total = 0  # 初始化总样本数
    with torch.no_grad():  # 评估时不需要计算梯度，加速推理
        for inputs, labels in data_loader:
            inputs, labels = inputs.to(device), labels.to(device)  # 将数据迁移到设备上
            outputs = model(inputs)  # 前向传播得到预测输出
            loss = criterion(outputs, labels)  # 计算当前批次的损失
            test_loss += loss.item() * inputs.size(0)  # 累加损失
            _, predicted = torch.max(outputs, 1)  # 获取预测概率最高的类别索引
            total += labels.size(0)  # 统计处理过的样本总数
            correct += (predicted == labels).sum().item()  # 统计预测正确的样本数

    avg_loss = test_loss / len(data_loader.dataset)  # 计算平均损失
    accuracy = 100.0 * correct / total  # 计算准确率（百分比）
    print(f"Loss: {avg_loss:.4f}, Accuracy: {accuracy:.2f}%")  # 打印评估结果
    return accuracy  # 返回准确率

# 定义保存模型函数，将模型参数保存到指定路径
def save_model(model, save_path):
    torch.save(model.state_dict(), save_path)  # 仅保存模型的状态字典

# 主程序入口
if __name__ == "__main__":
    num_epochs = 10  # 设置训练的总轮数
    learning_rate = 0.001  # 设置优化器的学习率
    num_features = features.shape[1]  # 获取每个样本的特征数（特征维度）
    num_class = len(np.unique(labels))  # 根据标签的不同取值计算类别数量
    save_path = r"model_pth\best.pth"  # 设置模型保存的文件路径
    # 初始化GraphCNN模型，传入特征数和类别数，并将模型迁移到设备（GPU/CPU）
    model = GraphCNN(num_features, num_class).to(device)
    criterion = nn.CrossEntropyLoss()  # 使用交叉熵作为损失函数，适合分类任务
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)  # 使用Adam优化器更新模型参数
    # 开始训练模型
    train(model, train_loader, val_loader, criterion, optimizer, num_epochs)
    # 训练完成后在测试集上评估模型
    evaluate(model, test_loader, criterion)
